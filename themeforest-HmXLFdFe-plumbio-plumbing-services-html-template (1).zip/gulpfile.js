const gulp = require('gulp');
const concat = require('gulp-concat');
const autoprefixer = require('gulp-autoprefixer');
const cleanCSS = require('gulp-clean-css');
const terser = require('gulp-terser');
const del = require('del');
const browserSync = require('browser-sync').create();
const sass = require('gulp-sass');
const sourcemaps = require('gulp-sourcemaps');
const plumber = require('gulp-plumber');
const notify = require("gulp-notify");
const fileinclude = require('gulp-file-include');
const replace = require('gulp-replace');
const htmlmin = require('gulp-htmlmin');

function styles() {
   return gulp.src(
      [
         './src/scss/style.scss'
      ]
   )
   .pipe(plumber({errorHandler: notify.onError("Error: <%= error.message %>")}))
   .pipe(sass().on('error', sass.logError))
   .pipe(autoprefixer({
      overrideBrowserslist: ['last 1 versions'],
	  cascade: false
   }))
   // .pipe(cleanCSS({
   //    level: 1
   // }))
   .pipe(gulp.dest('./build/css'))
   .pipe(gulp.dest('./src/css'))
   .pipe(browserSync.stream());
}
const jsFiles = [
   './node_modules/swiper/swiper-bundle.js',
   './node_modules/lazysizes/lazysizes-umd.js',
   './node_modules/lazysizes/plugins/bgset/ls.bgset.js',
   './src/external/flatpickr/flatpickr.js',   
   './src/js/**/*.js'
];

function scripts() {
   return gulp.src(jsFiles,  { allowEmpty: true })
   .pipe(concat('bundle.js'))  
   // .pipe(terser({
   //    keep_fnames: true,
   //    mangle: false
   //  }))
   .pipe(gulp.dest('./build/js'))
   .pipe(browserSync.stream());
}
function clean() {
   return del(['build/*'])
}
function html() {
   return gulp.src('./src/*.html')
   .pipe(plumber({errorHandler: notify.onError("Error: <%= error.message %>")}))
   .pipe(fileinclude({
	  prefix: '@@',
	  basepath: '@file'
	}))
   .pipe(gulp.dest('./build/'))
   .pipe(browserSync.stream());
}
function favicon() {
   return gulp.src('./src/favicon.png')
   .pipe(gulp.dest('./build/'))
   .pipe(browserSync.stream());
}
function external() {
   return gulp.src('./src/external/**/*')
   .pipe(gulp.dest('./build/external/'))
   .pipe(browserSync.stream());
}
function font_icons() {
   return gulp.src('./src/font/**/*')
   .pipe(gulp.dest('./build/font/'))
   .pipe(browserSync.stream());
}
function scss() {
   return gulp.src('./src/scss/*')
   .pipe(gulp.dest('./build/scss/'))
   .pipe(browserSync.stream());
}
function ajaxContent() {
   return gulp.src('./src/ajax-content/*')
   .pipe(gulp.dest('./build/ajax-content/'))
   .pipe(browserSync.stream());
}
function img() {
   return gulp.src('./src/images/**/*')
   .pipe(gulp.dest('./build/images/'))
   .pipe(browserSync.stream());
}
function blogStyles() {
   return gulp.src('./src/include-separate/blog/style-blog.scss')
   .pipe(plumber({errorHandler: notify.onError("Error: <%= error.message %>")}))
   .pipe(sass().on('error', sass.logError))
   .pipe(autoprefixer({
      overrideBrowserslist: ['last 1 versions'],
   }))
   // .pipe(cleanCSS({
   //    level: 1
   // }))
   .pipe(gulp.dest('./build/include-separate/blog'))
   .pipe(browserSync.stream());
}
function cartStyles() {
   return gulp.src('./src/include-separate/page-cart/cart.scss')
   .pipe(plumber({errorHandler: notify.onError("Error: <%= error.message %>")}))
   .pipe(sass().on('error', sass.logError))
   .pipe(autoprefixer({
      overrideBrowserslist: ['last 1 versions'],
   }))
   .pipe(cleanCSS({
      level: 1
   }))
   .pipe(gulp.dest('./build/include-separate/page-cart'))
   .pipe(browserSync.stream());
}
function shopStyles() {
   return gulp.src('./src/include-separate/shop/shop.scss')
   .pipe(plumber({errorHandler: notify.onError("Error: <%= error.message %>")}))
   .pipe(sass().on('error', sass.logError))
   .pipe(autoprefixer({
      overrideBrowserslist: ['last 1 versions'],
   }))
   .pipe(cleanCSS({
      level: 1
   }))
   .pipe(gulp.dest('./build/include-separate/shop'))
   .pipe(browserSync.stream());
}

function folderTransfer() {
   return gulp.src('./src/include-separate/**/*')
   .pipe(gulp.dest('./build/include-separate/'))
   .pipe(browserSync.stream());
}

function watch() {
   browserSync.init({
	  server: {
		  baseDir: "./build/"
	  }
  });
  gulp.watch('./src/include-separate/blog/style-blog.scss', blogStyles)
  gulp.watch('./src/include-separate/page-cart/cart.scss', cartStyles)
  gulp.watch('./src/include-separate/shop/shop.scss', shopStyles)
  gulp.watch('./src/scss/**/*.scss', styles)
  gulp.watch('./src/js/**/*.js', scripts)
  gulp.watch('./src/**/*.html', gulp.series(html)).on('change', browserSync.reload);
}

gulp.task('styles', styles);
gulp.task('blogStyles', blogStyles);
gulp.task('cartStyles', cartStyles);
gulp.task('shopStyles', shopStyles);
gulp.task('html', html);
gulp.task('scripts', scripts);
gulp.task('del', clean);
gulp.task('img', img);
gulp.task('folderTransfer', folderTransfer);
gulp.task('external', external);
gulp.task('font_icons', font_icons);
gulp.task('favicon', favicon);
gulp.task('ajaxContent', ajaxContent);
gulp.task('watch', watch);
gulp.task('build', gulp.series(clean, gulp.parallel(styles,favicon,external,font_icons,scss,ajaxContent,img,scripts,html,blogStyles, cartStyles, shopStyles, folderTransfer)));


gulp.task('html-minify', () => {
   return gulp.src('./build/*.html')
     .pipe(htmlmin({ collapseWhitespace: true }))
     .pipe(gulp.dest('./build/'));
 });


gulp.task('dev', gulp.series('build','watch'));