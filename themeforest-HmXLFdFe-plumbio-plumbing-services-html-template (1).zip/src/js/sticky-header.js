function findOffset(element) {
  var top = 0, left = 0;
  do {
	top += element.offsetTop  || 0;
	left += element.offsetLeft || 0;
	element = element.offsetParent;
  } while(element);
  return {
	top: top,
	left: left
  };
}

window.onload = function () {
	var stickyHeader = document.getElementById('js-init-sticky');
	var headerOffset = findOffset(stickyHeader);

	if(stickyHeader && headerOffset){
		window.onscroll = function() {
			initStickyheader();
		};
		initStickyheader();
	};
	function initStickyheader(){
		var bodyScrollTop = document.documentElement.scrollTop || document.body.scrollTop;

		if (bodyScrollTop >= headerOffset.top) {
			stickyHeader.classList.add('sticky-header');
		} else {
			stickyHeader.classList.remove('sticky-header');
		}
	};
};


