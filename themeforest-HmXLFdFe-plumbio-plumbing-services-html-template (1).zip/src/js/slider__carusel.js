/*
	Carusel
*/
(function(){
	function initCarusel(searchpoint){
		document.querySelectorAll('#' + searchpoint + ' [data-carousel="swiper"]').forEach(function(objCarusel){
			var slidesXXl = objCarusel.dataset.slidesXxl,
				slidesXl = objCarusel.dataset.slidesXl,
				slidesLg = objCarusel.dataset.slidesLg,
				slidesMd = objCarusel.dataset.slidesMd,
				slidesSm = objCarusel.dataset.slidesSm,
				slidesSm = objCarusel.dataset.slidesSm,
				autoplayDelay = objCarusel.dataset.autoplayDelay,
				spaceBetween = Number(objCarusel.dataset.spaceBetween),
				arrowLeft = objCarusel.getElementsByClassName("swiper-next")[0],
				arrowRight = objCarusel.getElementsByClassName("swiper-prev")[0];


			var swiper = new Swiper(objCarusel, {
				watchOverflow:true,
				spaceBetween:  spaceBetween  || 15,
				pagination: {
					el: '.swiper-pagination',
					clickable: true,
				},
				navigation: {
					nextEl: arrowLeft,
					prevEl: arrowRight,
					clickable: true
				},
				autoplay:{
					delay:autoplayDelay || 5000,
					stopOnLastSlide: false,
					disableOnInteraction: false
				},
				autoHeight:true,

				speed: 1000,
				breakpoints: {
					320: {
						slidesPerView: slidesSm || 2
					},
					576: {
						slidesPerView: slidesMd || 2,
						autoHeight: true,
					},
					768: {
						slidesPerView: slidesLg || 2,
						spaceBetween:  spaceBetween  || 30,
					},
					1025: {
						slidesPerView: slidesXl || 3
					},
					1500: {
						slidesPerView: slidesXXl || 3
					}
				},
				preloadeImages: false

			});
			window.addEventListener('resize', function () {
				var timer;
				if (timer) {
					clearTimeout(timer);
				}
				timer = setTimeout(function(){
					swiper.updateAutoHeight();
				}, 200);
			});
			window.addEventListener('DOMContentLoaded', function () {
				var timer;
				if (timer) {
					clearTimeout(timer);
				}
				timer = setTimeout(function(){
					swiper.update();
				}, 200);
			});
		});
	};
	initCarusel('tt-pageContent');
})();

(function(){
	var caruselGalleryLarge = document.querySelector('.gallery-large'),
		caruselGalleryThumbs = document.querySelector('.gallery-thumbs');

	if(caruselGalleryLarge && caruselGalleryThumbs){
		var galleryTop = new Swiper(caruselGalleryLarge, {
			spaceBetween: 10,
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			},
			loop: true,
			loopedSlides: 4,
			onSlideChangeEnd: function (s) {
				console.log('onSlideChangeEnd');
			}
		});
		var galleryThumbs = new Swiper(caruselGalleryThumbs, {
			spaceBetween: 14,
			slidesPerView: 4,
			slideToClickedSlide: true,
			loop: true,
			loopedSlides: 4,
			on:{
				progress: function() {
					Array.prototype.slice.call(caruselGalleryLarge.querySelectorAll('video')).forEach(function(obj) {
						obj.pause();
						obj.parentNode.classList.remove('tt-show-video');
					});
				}
			}
		});
		galleryTop.controller.control = galleryThumbs;
		galleryThumbs.controller.control = galleryTop;

		window.addEventListener('DOMContentLoaded', function () {
				var timer;
				if (timer) {
					clearTimeout(timer);
				}
				timer = setTimeout(function(){
					galleryTop.update();
					galleryThumbs.update();
				}, 500);
			});


		function playVideoLinks(){
			var linkVideo = document.querySelectorAll("#tt-pageContent .tt-link-video video"),
				linkVideoArray = Array.prototype.slice.call(linkVideo);
			if(linkVideo){
				if(document.body.classList.contains('touch-device')){
					var objEvents = 'touchstart';
				} else {
					var objEvents = 'click';
				};
				linkVideoArray.forEach(function(el) {
					el.addEventListener(objEvents, function(e) {
						event.preventDefault();
						var objWrapper = e.target.parentNode;
						if(!objWrapper.classList.contains('tt-show-video')){
							objWrapper.classList.add('tt-show-video');
							this.play();
						} else if(objWrapper.classList.contains('tt-show-video')){
							this.pause();
							objWrapper.classList.remove('tt-show-video');
						};
					});
				});
			}
		}
		playVideoLinks();
	};
})();

