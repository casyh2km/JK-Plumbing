function hasClass(elem, className) {
	return elem.classList.contains(className);
};
var popupDropdown = (function(){
	var obj = document.querySelector("#js-header .tt-popup"),
		$body = document.body,
		$objLockOffsetRight = document.querySelector("#js-init-sticky");
	document.addEventListener('click', function (e) {
		var $target = e.target,
			objWrapper = document.getElementById('js-popup-wrapper'),
			withScroll = window.innerWidth - document.documentElement.clientWidth;

		checkInclude($target);
		if(!objWrapper){
			createPopupWrapper();
		};
		openPopup($target, withScroll);
		closePopup($target);
	}, false);
	function createPopupWrapper(){
		obj.insertAdjacentHTML('beforeend', '<div class="tt-popup__wrapper" id="js-popup-wrapper"></div>');
	};
	function openPopup($target, withScroll){
		if (hasClass($target, 'tt-popup__toggle')) {
			lockOffsetRight(withScroll);
			lockOffsetTop();
			$target.closest('.tt-popup').classList.toggle('to-show');
			$body.classList.toggle('tt-pupup-open');
			disableScroll();
		};
	};
	function lockOffsetTop(){
		var valueScroll = $body.scrollTop || document.documentElement.scrollTop;
		$body.style.top = valueScroll + 'px';
	}
	function lockOffsetRight(withScroll){
		$body.style.paddingRight = withScroll + 'px';
		if($objLockOffsetRight.classList.contains('sticky-header')){
			$objLockOffsetRight.style.paddingRight = withScroll + 'px';
		}
	};
	function closePopup($target){
		if (hasClass($target, 'tt-popup__toggle') && !hasClass(obj, 'to-show')){
			document.querySelector("#js-popup-wrapper").click();
		};
		if (hasClass($target, 'tt-popup__close')) {
			$target.closest('.tt-popup').classList.remove('to-show');
			$body.classList.remove('tt-pupup-open');
			$body.removeAttribute("style");
			$objLockOffsetRight.removeAttribute("style");
			enableScroll();
		};
	};
	function checkInclude($target){
		if ($target.classList.contains('tt-popup__toggle')){
			var valueInclude = $target.closest('.tt-popup').dataset.ajaxCheck;
			if(valueInclude === 'true'){
				include();
			};
		};
	};
	function include(){
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var pointInclude = document.querySelector("#js-popup .tt-popup__dropdown");
				pointInclude.innerHTML = this.responseText;
				menuMobile();
				new PerfectScrollbar(pointInclude, {
					wheelSpeed: 2,
					wheelPropagation: true,
					minScrollbarLength: 20
				});
			}
		};
		xhttp.open("GET", 'ajax-content/header-popup.html', true);
		xhttp.send();
	};
	window.addEventListener("resize", close);
	function close(){
		if (hasClass($body, 'tt-pupup-open')) {
			obj.querySelector(".tt-popup__toggle").touchstart();
		};
	};
	document.addEventListener('click', function(event) {
		var e = document.getElementById('js-popup-wrapper');
		if (e.contains(event.target)){
			document.querySelector("#js-header .tt-popup__close").click();
		};
	});
	function preventDefault(e){
		e.preventDefault();
	};
	function disableScroll(){
		document.body.addEventListener('touchmove', preventDefault, { passive: false });
	};
	function enableScroll(){
		document.body.removeEventListener('touchmove', preventDefault);
	};
}());


