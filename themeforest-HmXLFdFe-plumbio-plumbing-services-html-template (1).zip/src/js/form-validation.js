/*
	Validation is performed in such fields:
		data-validate-field="name"
		data-validate-field="email"
		data-validate-field="number"
		data-validate-field="empty"
*/
function validationInit(){
	var formObj = document.querySelectorAll("[data-form='validation']"),
		formObjArray = Array.prototype.slice.call(formObj);

	var isSubmit = false,
		messageErrorName = 'Please enter a valid name',
		messageErrorEmail = 'Please enter a valid Email',
		messageErrorNumber = 'Please enter a valid Telephone',
		messageErrorEmpty = 'Please fill in the field';

	const regExpName = /^[a-z0-9_-]{3,16}$/;
	const regExpEmail = /^[A-Z0-9._%+-]+@[A-Z0-9-]+.+.[A-Z]{2,4}$/i;
	const regExpNumber = /[0-9]+/;
	const regExpEmpty = /^\s+/;


	if(formObjArray){
		formObjArray.forEach(function(wrapperForm){
			wrapperForm.addEventListener("submit", function(event){
				event.preventDefault();
				var $target = event.target;
				checkAllFields($target, wrapperForm);
			});
			function checkAllFields($target){
				var tagForm = $target.closest('form'),
					formElement = tagForm.querySelectorAll("[data-validate-if]"),
					formElementArray = Array.prototype.slice.call(formElement);

				formElementArray.forEach(function(el){
					if(el.dataset.validateIf === "false"){
						el.parentElement.classList.add('error-field');
						isSubmit = false;
					};
				});
				sendForm($target, wrapperForm);
			};
			function sendForm($target, wrapperForm){
				if(isSubmit){
					var formData = new FormData(wrapperForm);
					var request = new XMLHttpRequest();
					var srcHandler = wrapperForm.dataset.srcHandler;
					request.open("POST", srcHandler);
					request.send(formData);
					wrapperForm.reset();
					if (document.body.classList.contains('show-modal')) {
						closeModal();
					} else{
						showMessageSuccessful(wrapperForm);
					};
				}
			};
			function showMessageSuccessful(wrapperForm){
				objModalMessage = wrapperForm.querySelector('.tt-modal-message');
				objModalMessage.classList.add('tt-active');
				setTimeout(function(){
					objModalMessage.classList.remove('tt-active');
				}, 1600);
			};
			function closeModal(){
				var $body = document.body,
					objModal = document.querySelector('.tt-modal__open'),
					objModalMessage =objModal.querySelector('.tt-modal-message'),
					objModalClose = objModal.querySelector('.tt-modal__close');

				if(objModalMessage){
					objModalMessage.classList.add('tt-active');
				};
				setTimeout(function(){
					if(objModalMessage){
						objModalMessage.classList.remove('tt-active');
					};
					if(objModalClose){
						objModalClose.click();
					};
				}, 1600);
			};
			if( !/iPhone|iPad|iPod/i.test(navigator.userAgent) ) {
				checkingEnteredValues(wrapperForm);
			}
		});
	};
	function checkingEnteredValues(wrapperForm){
		for (var item of wrapperForm) {
			if(item.dataset.validateField){
				item.dataset.validateIf = false;
				item.addEventListener('blur', function(){
					var $this = this;
					validateItem($this)
				})
			}
		}
	}
	function validateItem($this){
		var value = $this.dataset.validateField,
			wrapperField = $this.parentElement;
		if(value === "name"){
			!regExpName.test($this.value) && $this.value !== "" ? showError(messageErrorName) : hideError($this);
		};
		if(value === "email"){
			!regExpEmail.test($this.value) && $this.value !== "" ? showError(messageErrorEmail) : hideError($this);
		};
		if(value === "number"){
			!regExpNumber.test($this.value) && $this.value !== "" ? showError(messageErrorNumber) : hideError($this);
		};
		if(value === "empty"){
			$this.value == "" ? showError(messageErrorEmpty) : hideError();
		};
		function showError(message){
			wrapperField.classList.add('error-field');
			wrapperField.insertAdjacentHTML('beforeend', `<div class="error-field__text">${message}</div>`);
			isSubmit = false;
		};
		function hideError(){
			$this.dataset.validateIf = "true";
			wrapperField.classList.remove('error-field');
			var blockHtml =  wrapperField.querySelector('.error-field__text');
			if(blockHtml){
				blockHtml.remove();
			}
			isSubmit = true;
		};
	};
};
validationInit();
