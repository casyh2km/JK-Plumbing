(function(){
	var btnTop = document.getElementById('js-backtotop');
	if(!btnTop) return;
	window.addEventListener('scroll', showBtn);
	btnTop.addEventListener('click', scrollTop);
	function showBtn(){
		var bodyScrollTop = document.documentElement.scrollTop || document.body.scrollTop;
		bodyScrollTop > 1000 ? btnTop.classList.add('tt-show') : btnTop.classList.remove('tt-show');
	};
	function scrollTop(){
		if(!window.pageYOffset > 0) return;
		window.scrollTo({top: 0, behavior: 'smooth'});
	};
})();
