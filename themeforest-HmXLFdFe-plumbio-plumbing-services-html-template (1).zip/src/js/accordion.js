var accordion = (function(){
	var objAccordeon = document.querySelectorAll("#tt-pageContent .js-accordeon"),
		objAccordeonArray = Array.prototype.slice.call(objAccordeon);
	if(objAccordeon){
		objAccordeonArray.forEach(function(el) {
			el.addEventListener("click", function(e) {
				if(e.target.classList.contains('tt-collapse__title') && e.target.parentNode.classList.contains('tt-show')){
					e.target.parentNode.classList.remove('tt-show');
				} else if(e.target.classList.contains('tt-collapse__title') && !e.target.parentNode.classList.contains('tt-show')){
					var wrapper = e.target.closest('.js-accordeon');
					wrapper.querySelectorAll(".tt-collapse__item").forEach(function(el) {
						if(el.classList.contains('tt-show')){
							el.classList.remove('tt-show');
						}
					});
					e.target.parentNode.classList.add('tt-show');
				};
			});
		});
	}
}());
