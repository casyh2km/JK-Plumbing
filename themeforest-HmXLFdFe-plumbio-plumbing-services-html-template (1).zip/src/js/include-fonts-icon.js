(function () {
	var giftofspeed = document.createElement('link');
	giftofspeed.rel = 'stylesheet';
	giftofspeed.href = 'font/style.min.css';
	giftofspeed.type = 'text/css';
	var godefer = document.getElementsByTagName('link')[0];
	godefer.parentNode.insertBefore(giftofspeed, godefer);
}());