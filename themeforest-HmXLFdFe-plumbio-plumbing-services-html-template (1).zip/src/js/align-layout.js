(function(){
	function alignLayout(){
		var objWraper = document.querySelectorAll("#tt-pageContent .js-align-layout"),
			objWraperArray = Array.prototype.slice.call(objWraper);
		if(objWraper){
			objWraperArray.forEach(function(item) {
				item.querySelectorAll(".js-align-layout__item").forEach(function(element){
					element.removeAttribute("style");
				});
				var heightOffset = 0;
				item.querySelectorAll(".js-align-layout__item").forEach(function(element) {
					height = getAbsoluteHeight(element);
					if(height > heightOffset){
						heightOffset = height;
					}
				});
				item.querySelectorAll(".js-align-layout__item").forEach(function(element){
					element.style.minHeight = heightOffset + 'px'
				});
			});
		};
		function getAbsoluteHeight(el) {
			el = (typeof el === 'string') ? document.querySelector(el) : el;
			var styles = window.getComputedStyle(el);
			return el.offsetHeight;
		};
	};
	var timer01;
	if (timer01) {
		clearTimeout(timer01);
	}
	timer01 = setTimeout(function(){
		alignLayout();
	}, 300);
	window.addEventListener('resize', function (){
		var timer02;
		if (timer02) {
			clearTimeout(timer02);
		}
		timer02 = setTimeout(function(){
			alignLayout();
		}, 300);
	});
})();