var menuDesktop = (function(){
	function dropdownHandler(){
		if(window.innerWidth >= 1100){
			document.querySelectorAll('#js-desktop-menu li').forEach(function(dropdownItem){
				dropdownItem.querySelectorAll('ul').forEach(function(itemUl){
					var objUl = itemUl.parentNode;
					objUl.classList.add('has-submenu');
				});
				dropdownItem.onmouseenter = function(event, dropdownItem){
					var $this = (this);
					dropdown_delay = setTimeout(function(dropdownItem){
						if(!event.target) return false;
						dropdownItem.classList.add('is-active');
					}, 200, $this);
				};
				dropdownItem.onmouseleave = function(event, dropdownItem){
					clearTimeout(dropdown_delay);
					(this).classList.remove('is-active');
				};
			});
		};
	};
	dropdownHandler();
	window.addEventListener("resize", dropdownHandler);
})();