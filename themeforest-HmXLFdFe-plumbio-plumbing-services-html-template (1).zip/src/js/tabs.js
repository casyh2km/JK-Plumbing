var tabs = (function(){
	if(document.body.classList.contains('touch-device')){
		var objEvents = 'touchstart';
	} else {
		var objEvents = 'click';
	};
	document.body.addEventListener(objEvents, function(event) {
		if(event.target.classList.contains('tabs__nav-item')){
			var $target = event.target;
			checkInclude($target);
			checkNavActive($target);
			checkTabActive($target);
			checkIncludeFalse($target);
		};
		function checkNavActive($target){
			var navItem = $target.parentNode.querySelectorAll('.tabs__nav-item'),
				navItemArray = Array.prototype.slice.call(navItem);

			navItemArray.forEach(function(navItem){
				if(navItem.classList.contains('active')){
					navItem.classList.remove("active");
				}
			});
			$target.classList.add("active");
		};
		function checkTabActive($target){
			var pathtabActive = $target.dataset.pathtab,
				srcItem = document.querySelector("#" + pathtabActive),
				layouyItem = srcItem.parentNode.querySelectorAll('.tabs__layout-item'),
				layouyItemArray = Array.prototype.slice.call(layouyItem);

			layouyItemArray.forEach(function(tabItem){
				if(tabItem.classList.contains('active')){
					tabItem.classList.remove("active");
				}
			});
			srcItem.classList.add("active");
		};
		function checkInclude(el){
			var vaueInclude = el.closest('.js-tabs').dataset.ajaxcheck;
			if(vaueInclude){
				var layouyItem = el.closest('.js-tabs').querySelectorAll('.tabs__container .tabs__layout-item'),
					layouyItemArray = Array.prototype.slice.call(layouyItem);
				layouyItemArray.forEach(function(item){
					var valueSrc = item.dataset.include;
					if(valueSrc){
						var xhttp = new XMLHttpRequest();
						xhttp.onreadystatechange = function() {
							if (this.readyState == 4 && this.status == 200) {
								item.innerHTML = this.responseText;
							}
						};
						xhttp.open("GET", valueSrc, true);
						xhttp.send();
					}
				});
			}
		};
		function checkIncludeFalse($target){
			$target.closest('.js-tabs').dataset.ajaxcheck = 'false';
		};
	}, false);
}());
