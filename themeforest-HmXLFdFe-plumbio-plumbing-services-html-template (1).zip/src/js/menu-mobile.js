function menuMobile(){
	var objMenu = document.getElementById("js-mobile-menu"),
		objMenuNav =  objMenu.querySelector("nav"),
		objMenuHeight = objMenu.offsetHeight;

	Array.prototype.slice.call(objMenu.querySelectorAll('li')).forEach(function(itemUl){
		var obj = itemUl.querySelectorAll('ul').length;
		if(obj > 0){
			itemUl.classList.add('has-submenu');
			itemUl.insertAdjacentHTML('afterbegin', `<div class="link__open-submenu"></div>`)
		}
	});
	objMenu.addEventListener('click', function(e){
		if(e.target && e.target.classList.contains('link__open-submenu')) showSubmenu(e.target);
		if(e.target && e.target.classList.contains('tt-mobile-menu__back')) stepBack();
	});
	function showSubmenu($target){

		$target.parentNode.classList.add('active');
		setHeight($target);

		var getValueLeft = objMenuNav.style.left || 0,
			setNewValue = parseInt(getValueLeft) - 100;

		objMenuNav.style.left=setNewValue + "%";
		if(!objMenu.classList.contains('submenu-visible')){
			objMenu.classList.add('submenu-visible');
		};

	};
	function setHeight($target){
		$target.parentNode.classList.add('active');
		var objMenuHeightNew = $target.parentNode.querySelector("ul").offsetHeight;
		if(objMenuHeight < objMenuHeightNew){
			objMenu.style.minHeight = objMenuHeightNew + 40 + 'px';
		}
	};
	function stepBack(){
		var getValueLeft = objMenuNav.style.left || 0,
			setNewValue = parseInt(getValueLeft) + 100;

		objMenuNav.style.left=setNewValue + "%";
		if(setNewValue == 0){
			objMenu.classList.remove('submenu-visible');
			document.querySelectorAll('#js-mobile-menu li').forEach(function(item){
				if(item.classList.contains('active')) {
					item.classList.remove('active');
				};
			});
		};
		var actives = Array.prototype.slice.call(objMenu.querySelectorAll('li.active'));
		var lastActive = actives[(actives.length - 1)] || false;
		if(lastActive){
			lastActive.classList.remove('active');
		}
		objMenu.style.minHeight = objMenuHeight + 'px';
	};
}
