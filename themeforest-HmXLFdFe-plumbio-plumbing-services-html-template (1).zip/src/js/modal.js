var modal = (function(options){
	var modalLinks = document.querySelectorAll('div[data-modal]'),
		$objLockOffsetRight = document.querySelector("#js-init-sticky"),
		$body = document.body;
	if(modalLinks){
		document.addEventListener('click', function(e){
			if (event.target.hasAttribute('data-modal')) {
				var nameModal = event.target.dataset.modal,
					sizeModal = event.target.dataset.modalSize,
					srcModal = event.target.dataset.modalSrc;
				initModal(nameModal, sizeModal, srcModal);
			};
		}, false);
	};
	function initModal(nameModal, sizeModal, srcModal){
		if($body.classList.contains('tt-pupup-open')){
			document.querySelector('#js-popup .tt-popup__toggle').click();
		};
		createModalWrapper(nameModal, sizeModal);
		includeLayout(nameModal, srcModal);
		setTimeout(function() {
			flatpickr(".tt-flatpickr-time", {
				enableTime: true,
				noCalendar: true,
				dateFormat: "H:i",
			});
			flatpickr(".tt-flatpickr", {
				wrap: true,
			});
		}, 400)
	};
	function createModalWrapper(nameModal, sizeModal){
		$body.insertAdjacentHTML('beforeend', `<div class="tt-modal" id="${nameModal}">
			<div class="tt-modal__wrapper"></div>
			<div class="tt-modal__body ${sizeModal}">
				<div class="tt-modal__close icon-748122"><label>Close</label></div>
				<div class="tt-modal__layout"></div>
			</div>
		</div>`);
		return modal;
	};
	function includeLayout(nameModal, srcModal){
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.querySelector("#" + nameModal+  ' .tt-modal__layout').innerHTML =
				this.responseText;
			}
		};
		xhttp.open("GET", srcModal, true);
		xhttp.send();
		var withScroll = window.innerWidth - document.documentElement.clientWidth;
		setTimeout(function(){
			showModal(nameModal, withScroll);
		}, 200);
	};
	function showModal(nameModal, withScroll){
		$body.classList.add('show-modal');
		document.getElementById(nameModal).classList.add('tt-modal__open');
		hangHandlerClose(nameModal);
		lockOffsetRight(withScroll);
		clickoutside(nameModal);
		setTimeout(function(){
			uploadFile(nameModal);
		}, 100);
		setTimeout(function(){
			initScroll(nameModal);
			validationInit();
		}, 200);
		var checkWidth = window.innerWidth;
		window.addEventListener("resize", function(){
			var newWidth = window.innerWidth;
			if(newWidth !== checkWidth){
				closeModal(nameModal);
			}
		});
	};
	function closeModal(nameModal){
		$body.classList.remove('show-modal');
		$body.removeAttribute("style");
		$objLockOffsetRight.removeAttribute("style");
		document.getElementById(nameModal).classList.remove('tt-modal__open');
		enableScroll();
		setTimeout(function(){
			var elem = document.getElementById(nameModal);
			if (elem.length > 0) {
				elem.remove();
			}
		}, 1400);
	};
	function hangHandlerClose(nameModal){
		objAsideClose = document.getElementById(nameModal);
		objAsideClose.querySelector(".tt-modal__close").addEventListener("click", function(e){
			closeModal(nameModal);
		});
	};
	function lockOffsetRight(withScroll){
		$body.style.paddingRight = withScroll + 'px';
		if($objLockOffsetRight.classList.contains('sticky-header')){
			$objLockOffsetRight.style.paddingRight = withScroll + 'px';
		}
	};
	function clickoutside(nameModal){
		if(document.body.classList.contains('touch-device')){
			var objEvents = 'touchstart';
		} else {
			var objEvents = 'click';
		};
		document.addEventListener(objEvents, function(event) {
			if (event.target.classList.contains("tt-modal__wrapper")){
				closeModal(nameModal);
			}
		});
	};
	function uploadFile(nameModal){
		document.querySelectorAll("#" + nameModal +" .tt-upload__item").forEach(function(objItem){
			objItem.addEventListener("click", function(e) {
				var $this = this;
				$this.querySelector('input').click();
				$this.addEventListener('change', changeInput);
			});
		});
	};
	function initScroll(nameModal){
		var obj = document.querySelector("#" + nameModal),
			pointInitScroll = obj.querySelector(".tt-modal__body"),
			pointHeight = pointInitScroll.clientHeight,
			viewportHeight = window.innerHeight;

		if(viewportHeight <= pointHeight){
			disableScroll();
			obj.querySelector(".tt-modal__close").classList.add('btn-close__inner');
			pointInitScroll.classList.add('fixed-height');
			new PerfectScrollbar(pointInitScroll);
		};
	};
	function changeInput(event){
		if(event.target.files.length > 0){
			event.target.parentNode.classList.add("tt-files-uploaded");
		}
	};
	function preventDefault(e){
		e.preventDefault();
	};
	function disableScroll(){
		window.addEventListener('touchmove', preventDefault, { passive: false });
	};
	function enableScroll(){
		window.removeEventListener('touchmove', preventDefault,  { passive: false });
	};
}());

