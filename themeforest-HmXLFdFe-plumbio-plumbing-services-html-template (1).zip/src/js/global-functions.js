var $body = document.body;
var supportsTouch = 'ontouchstart' in window || navigator.msMaxTouchPoints;
if(supportsTouch === true) $body.classList.add('touch-device');
if(/iPhone|iPad|iPod/i.test(navigator.userAgent))  $body.classList.add('is-ios');