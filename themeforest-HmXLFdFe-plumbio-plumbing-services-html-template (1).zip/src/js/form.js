/* Form Init Data*/
flatpickr(".tt-flatpickr", {
	wrap: true,
});
/* Form Init Time */
flatpickr(".tt-flatpickr-time", {
	enableTime: true,
	noCalendar: true,
	dateFormat: "H:i",
});
/* Blog Init alendar */
flatpickr("#init-calendar", {
	inline: true
});

