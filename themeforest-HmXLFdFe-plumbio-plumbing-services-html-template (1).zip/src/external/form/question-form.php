<?php header("Content-Type: text/html; charset=utf-8");?>
<?php
	$to = "youremail@gmail.com";
	$from = 'email';
	$name = 'name';
	$headers = "From: $from";
	$subject = "You have a message.";

	$fields = array();
	$fields{"name"} = "Your Name";
	$fields{"email"} = "Your Email";
	$fields{"phonenumber"} = "Phone";
	$fields{"message"} = "Question";

	$body = "Here is what was sent Plumbio, form 'Asq Your Question':\n\n";
	foreach($fields as $a => $b){
		$body .= sprintf("%20s:%s\n",$b,$_REQUEST[$a]);
	}
	$send = mail($to, $subject, $body, $headers);

?>
