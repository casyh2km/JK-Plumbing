# vanilla-calendar
It's a simple calendar in JS Vanilla
