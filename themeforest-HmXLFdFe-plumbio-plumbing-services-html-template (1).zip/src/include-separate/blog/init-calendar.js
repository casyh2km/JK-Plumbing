let myCalendar = new VanillaCalendar({
	selector: "#init-calendar-blog",
	shortWeekday: ['S', 'M', 'T', 'W', 'T', 'F', 'S']
})